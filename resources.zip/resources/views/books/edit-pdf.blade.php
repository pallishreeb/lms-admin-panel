@extends('layouts.editor')

@section('content')
<div id="app"></div>
<!-- <script src="{{ asset('build/assets/app--gHUpRXk.js') }}"></script> -->

@endsection
