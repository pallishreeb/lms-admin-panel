Your OTP is: {{ $otp }}
